package ar.edu.unlam.pb2.BarHomeroTest;

import java.util.TreeSet;
import org.junit.Assert;
import org.junit.Test;
import ar.edu.unlam.pb2.BarHomero.BarHomero;
import ar.edu.unlam.pb2.BarHomero.Cliente;

public class BarHomeroTest {

	@Test
	public void queElBarSeAbraSinClientes() {

		BarHomero barSinClientes = new BarHomero();
		Assert.assertEquals(0, barSinClientes.ListaDeClientes.size());
	}

	@Test(expected = Exception.class)
	public void barConClientesOrdenadosPorNombre() throws Exception {

		BarHomero bar = new BarHomero();

		bar.agregarCliente(new Cliente("Homero Simpson ", 39));
		bar.agregarCliente(new Cliente("Bart Simpson ", 10));
		bar.agregarCliente(new Cliente("Marge Simpson ", 38));
		bar.agregarCliente(new Cliente("Montgomery Burns ", 80));
		bar.agregarCliente(new Cliente("Lisa Simpson ", 9));
		bar.agregarCliente(new Cliente("Apu Nahasapeemapetilon ", 35));
		bar.agregarCliente(new Cliente("Ned Flanders ", 37));
		bar.agregarCliente(new Cliente("Milhouse Van Houten ", 10));
		bar.agregarCliente(new Cliente("Waylon Smithers ", 45));
		bar.agregarCliente(new Cliente("Barney Gumble ", 41));
		bar.agregarCliente(new Cliente("Edna Krabappel ", 37));
		bar.agregarCliente(new Cliente("Nelson Muntz ", 12));
		bar.agregarCliente(new Cliente("Seymour Skinner ", 38));
		bar.agregarCliente(new Cliente("Troy McClure ", 45));

		System.out.println("\n Clientes Ordenados alfabeticamente: \n");

		for (Cliente inicio : bar.ListaDeClientes) {
			System.out.println(" Nombre: " + inicio.getNombre() + ", Edad: " + inicio.getEdad());
		}

		// 10 personajes son los mayores de 18 a�os dentro del bar.
		Assert.assertEquals(10, bar.ListaDeClientes.size());

	}

	@Test(expected = Exception.class)
	public void barConClientesOrdenadosPorEdad() throws Exception {
		BarHomero bar = new BarHomero();

		Cliente cliente1 = new Cliente("Homero Simpson ", 39);
		Cliente cliente2 = new Cliente("Marge Simpson ", 38);
		Cliente cliente3 = new Cliente("Montgomery Burns ", 80);
		Cliente cliente4 = new Cliente("Apu Nahasapeemapetilon ", 35);
		Cliente cliente5 = new Cliente("Ned Flanders ", 37);
		Cliente cliente6 = new Cliente("Waylon Smithers ", 45);
		Cliente cliente7 = new Cliente("Barney Gumble ", 41);
		Cliente cliente8 = new Cliente("Edna Krabappel ", 37);
		Cliente cliente9 = new Cliente("Seymour Skinner ", 38);
		Cliente cliente10 = new Cliente("Troy McClure ", 45);

		TreeSet<Cliente> listaEsperada = new TreeSet<Cliente>();

		bar.agregarCliente(cliente1);
		bar.agregarCliente(cliente2);
		bar.agregarCliente(cliente3);
		bar.agregarCliente(cliente4);
		bar.agregarCliente(cliente5);
		bar.agregarCliente(cliente6);
		bar.agregarCliente(cliente7);
		bar.agregarCliente(cliente8);
		bar.agregarCliente(cliente9);
		bar.agregarCliente(cliente10);

		System.out.println("\n Clientes ordenados por edad: \n");

		Assert.assertEquals(listaEsperada, bar.comparandoLosClientesPorSuEdad());

	}

	@Test
	public void queCompareCorrectamenteClientesAdentroYfueraDelBar() {

		BarHomero bar = new BarHomero();

		try {
			bar.agregarCliente(new Cliente("Homero Simpson ", 39));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			bar.agregarCliente(new Cliente("Apu Nahasapeemapetilon ", 35));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			bar.agregarCliente(new Cliente("Barney Gumble ", 41));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			bar.agregarCliente(new Cliente("Edna Krabappel ", 37));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			bar.agregarCliente(new Cliente("Troy McClure ", 45));
		} catch (Exception e) {
			e.printStackTrace();
		}

		Cliente cliente = new Cliente("Homero Simpson ", 35);

		// comparo el nombre de un cliente de afuera con uno dentro del bar

		Assert.assertTrue(bar.comparandoClientesDentroYFueraDelBar(bar, cliente) == false);

	}
}
