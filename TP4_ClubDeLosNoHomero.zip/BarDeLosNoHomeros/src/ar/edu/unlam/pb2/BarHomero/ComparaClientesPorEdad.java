package ar.edu.unlam.pb2.BarHomero;

import java.util.Comparator;

public class ComparaClientesPorEdad implements Comparator<Cliente> {

	@Override
	public int compare(Cliente cliente1, Cliente cliente2) {
		Integer edadCliente1 = cliente1.getEdad();
		Integer edadCliente2 = cliente2.getEdad();
		return edadCliente1.compareTo(edadCliente2);
	}

}
