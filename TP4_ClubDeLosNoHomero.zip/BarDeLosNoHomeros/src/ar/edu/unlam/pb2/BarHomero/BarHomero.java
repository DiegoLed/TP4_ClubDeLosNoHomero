package ar.edu.unlam.pb2.BarHomero;

import java.util.Iterator;
import java.util.TreeSet;

public class BarHomero {

	private Integer cantidadDeClientes = 0;

	public TreeSet<Cliente> ListaDeClientes;

	public BarHomero() {
		ListaDeClientes = new TreeSet<Cliente>();
	}

	public void agregarCliente(Cliente cliente) throws Exception {
		if (cliente.getEdad()<18) {
			throw new Exception("No pueden ingresar menores de Edad al BAR DE LOS NO HOMERO");
		}
		else {
				cantidadDeClientes++;
				ListaDeClientes.add(cliente);
		}
	}

	public TreeSet<Cliente> getListaDeClientes() {
		return ListaDeClientes;
	}

	public void setListaDeClientes(TreeSet<Cliente> listaDeClientes) {
		ListaDeClientes = listaDeClientes;
	}

	public Integer getCantidadDeClientes() {
		return cantidadDeClientes;
	}

	public TreeSet<Cliente> comparandoLosClientesPorSuEdad() {

		ComparaClientesPorEdad edadAComparar = new ComparaClientesPorEdad();
		TreeSet<Cliente> ordenarClientes = new TreeSet<Cliente>(edadAComparar);

		ordenarClientes.addAll(ListaDeClientes);

		for (Cliente cliente : ordenarClientes) {

			System.out.println(cliente.getNombre() + cliente.getEdad());
		}

		return ordenarClientes;
	}

	public Boolean comparandoClientesDentroYFueraDelBar(BarHomero bar, Cliente cliente) {

		Boolean igualCliente = false;
		Iterator<Cliente> listaClientes = bar.ListaDeClientes.iterator();

		while (listaClientes.hasNext()) {
			Cliente unCliente = (Cliente) listaClientes.next();

			String nombreCliente = unCliente.getNombre();

			if (cliente.getNombre().equals(nombreCliente)) {
				igualCliente = true;
			} else {
				igualCliente = false;
			}
		}

		return igualCliente;

	}

}
